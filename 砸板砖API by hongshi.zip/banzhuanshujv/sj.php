<?php
$sj = rand(1,10);
?>
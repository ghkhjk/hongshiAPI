<?php
$banzhuana = rand(1,5);
?>
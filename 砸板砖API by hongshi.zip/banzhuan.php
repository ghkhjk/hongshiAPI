<?php
//欢迎使用hongshi禁言板砖
//这个是一个开源的API
//这个API只能独自使用（其实多人应该也可以）
//哦对温馨提示:
//使用前参考自带词库
include("./banzhuanshujv/sj.php");//调用没有这个运行不了
include("./banzhuanshujv/bzs.php");//调用没有这个运行不了
include("./banzhuanshujv/1.php");//调用没有这个运行不了
include("./banzhuanshujv/caidan.php");//调用没有这个运行不了
//     include("");      //为其他API预留
//     $zrqq = ;         //为其他API预留
$zrqq = 2188253950;//主人QQ-用处非常大
$bz=$_GET['bz'];//获取指令
$xgsl=$_GET['xgsl'];//修改初始数量必备条件
$qq=$_GET['qq'];//获取使用人QQ
$x=$_GET['x'];//修改时间小数
$d=$_GET['d'];//修改时间大数
$atqq=$_GET['atqq'];//艾特QQ
$qun=$_GET['qun'];//群号
$ng=$_GET['ng'];//修改菜单1内容输入
$ht=$_GET['ht'];//修改菜单1内容输入
//菜单
if ($bz =="禁言菜单"){
    echo $caidan;
}
//菜单2（为后续准备）
if ($bz =="禁言菜单1"){
    echo $caidan2;
}
//修改数量
if  ($bz == '修改初始数量'){
    if  ($qq == $zrqq){
        if  ($xgsl == 0){
            echo  "数量必须大于0";
        }
        if  ($xgsl > 0){
            $myfile = fopen("./banzhuanshujv/cssl.php", "w") or die("Unable to open file!");
            $txt = '';
            file_put_contents("./banzhuanshujv/cssl.php", "<?php \n$", FILE_APPEND);
            file_put_contents("./banzhuanshujv/cssl.php", "sl = $xgsl\n?>", FILE_APPEND);
            echo  "修改成功";
        }
    }
    if  ($qq != $zrqq){
        echo  "您不是本API的主人";
    }
}
//修改时间
if  ($bz == '修改每次砸板禁言时间'){
    if  ($qq == $zrqq){
        if  ($x > $d){
            echo  "修改失败\n失败原因:数值1比数值2大";
        }
        if  ($x < $d){
            $myfile = fopen("./banzhuanshujv/sj.php", "w") or die("Unable to open file!");
            $txt = '';
            file_put_contents("./banzhuanshujv/sj.php", "<?php\n", FILE_APPEND);
            file_put_contents("./banzhuanshujv/sj.php", "$", FILE_APPEND);
            file_put_contents("./banzhuanshujv/sj.php", "sj = rand", FILE_APPEND);
            file_put_contents("./banzhuanshujv/sj.php", "(", FILE_APPEND);
            file_put_contents("./banzhuanshujv/sj.php", "$x", FILE_APPEND);
            file_put_contents("./banzhuanshujv/sj.php", ",", FILE_APPEND);
            file_put_contents("./banzhuanshujv/sj.php", "$d", FILE_APPEND);
            file_put_contents("./banzhuanshujv/sj.php", ");\n", FILE_APPEND);
            file_put_contents("./banzhuanshujv/sj.php", "?>", FILE_APPEND);
            echo  "修改成功";
        }
    }
    if  ($qq != $zrqq){
        echo  "您不是本API的主人";
    }
}
//新人获取
if  ($bz == '新人获取'){
    include("./banzhuanshujv/cssl.php");
    $con = file_get_contents("./banzhuanshujv/xr.txt");
    $str = strstr($con,"$qq");
    if($str) $aaaaa = 2;
    else $aaaaa = 1;
    if  ($aaaaa == 1){
        $filename="./banzhuanshujv/bzs.php";
        $handle=fopen($filename,"a+");
        $str=fwrite($handle,'$'."a$qq"."="."$sl".";\n");
        fclose($handle);
        $filename="./banzhuanshujv/xr.txt";
        $handle=fopen($filename,"a+");
        $str=fwrite($handle,"$qq\n");
        fclose($handle);
        echo "获取成功";
    }
    if  ($aaaaa == 2){
        echo "你已经领取过啦";
    }
}
//砸板砖
if ($bz == '砸板砖'){
    $str = "a$qq";//账号名
    if ($$str > 0){
        $xinsj = $sj * 60; //秒时间
        $xinsj1 = $xinsj / 60; //分时间
        echo '$禁 '."$qun $atqq $xinsj".'$'."\nQQ:$qq"."\n成功禁言QQ:$atqq\n禁言时常:$xinsj1"."分钟";
        $aasassa = $$str;//获取aQQ值
        $aasassb = $aasassa - 1;//获取aQQ-1值
        $data = file_get_contents('./banzhuanshujv/bzs.php');
        $data_new = str_replace("a$qq".'='."$aasassa", "a$qq".'='."$aasassb", $data);
        $fp = fopen('./banzhuanshujv/bzs.php', 'r+');
        fwrite($fp, $data_new);
        fclose($fp);
    }   
    if ($$str == 0){
        echo "呀,板砖不够";
    }
}
//查板砖数量
if ($bz == '查板砖数'){
    $chaxun = "a$qq";//账号名
    $chaxunshu = $$chaxun;
    echo"QQ号:$qq"."\n"."板砖数:$chaxunshu";
}
//获取板砖
if ($bz == '获取板砖'){
    echo '搬砖'."\n";
    echo "偷砖";
}
//搬砖
if ($bz == '搬砖'){
    if ($banzhuana == 1){
        echo'$禁 '."$qun "."$qq ".'60$'."\n搬砖砸脚了\n还好不是很严重";
    }
    if ($banzhuana == 2){
        echo'$禁 '."$qun "."$qq ".'120$'."\n搬砖砸脚了\n有点严重";
    }    
    if ($banzhuana == 3){
        echo'$禁 '."$qun "."$qq ".'180$'."\n搬砖砸脚了\n成功进医院";
    }
    if ($banzhuana == 4){
        echo"完美搬完砖全部的砖\n奖励:0.5块砖";
        $str = "a$qq";//账号名
        $aasassa = $$str;//获取aQQ值
        $aasassb = $aasassa + 0.5;//获取aQQ+0.5值
        $data = file_get_contents('./banzhuanshujv/bzs.php');
        $data_new = str_replace("a$qq".'='."$aasassa", "a$qq".'='."$aasassb", $data);
        $fp = fopen('./banzhuanshujv/bzs.php', 'r+');
        fwrite($fp, $data_new);
        fclose($fp);
    }
    if ($banzhuana == 5){
        echo"完美搬完砖全部的砖\n奖励:1块砖";
        $str = "a$qq";//账号名
        $aasassa = $$str;//获取aQQ值
        $aasassb = $aasassa + 1;//获取aQQ+1值
        $data = file_get_contents('./banzhuanshujv/bzs.php');
        $data_new = str_replace("a$qq".'='."$aasassa", "a$qq".'='."$aasassb", $data);
        $fp = fopen('./banzhuanshujv/bzs.php', 'r+');
        fwrite($fp, $data_new);
        fclose($fp);
    }
}
//偷砖
if ($bz == '偷砖'){
    if ($banzhuana == 1){
        echo'$禁 '."$qun "."$qq ".'180$'."\n被发现了";
    }
    if ($banzhuana == 2){
        echo'$禁 '."$qun "."$qq ".'420$'."\n被发现了";
    }    
    if ($banzhuana == 3){
        echo'$禁 '."$qun "."$qq ".'720$'."\n被发现了";
    }
    if ($banzhuana == 4){
        echo"偷到2块\n奖励:2块砖";
        $str = "a$qq";//账号名
        $aasassa = $$str;//获取aQQ值
        $aasassb = $aasassa + 2;//获取aQQ+2值
        $data = file_get_contents('./banzhuanshujv/bzs.php');
        $data_new = str_replace("a$qq".'='."$aasassa", "a$qq".'='."$aasassb", $data);
        $fp = fopen('./banzhuanshujv/bzs.php', 'r+');
        fwrite($fp, $data_new);
        fclose($fp);
    }
    if ($banzhuana == 5){
        echo"偷到0.5块\n奖励:0.5块砖";
        $str = "a$qq";//账号名
        $aasassa = $$str;//获取aQQ值
        $aasassb = $aasassa + 0.5;//获取aQQ+0.5值
        $data = file_get_contents('./banzhuanshujv/bzs.php');
        $data_new = str_replace("a$qq".'='."$aasassa", "a$qq".'='."$aasassb", $data);
        $fp = fopen('./banzhuanshujv/bzs.php', 'r+');
        fwrite($fp, $data_new);
        fclose($fp);
    }
}
//购买装备
if ($bz =='购买装备'){
    echo "武器商店\n";
    echo "防具商店\n";
}
//砸板砖菜单
if ($bz == "砸板砖菜单"){
    echo"砸板砖 @QQ\n或者\n砸板砖 QQ号";
}
//主人系统
if ($bz == "主人系统"){
    echo"修改初始数量 [数字]\n修改每次砸板禁言时间 [数字] [数字]\n输出菜单\n生成词库 [http]/[https]";
}
//输出菜单
if  ($bz == '输出菜单'){
    if  ($qq == $zrqq){
        echo $caidann;
    }
    if  ($qq != $zrqq){
        echo  "您不是本API的主人";
    }
}
//生成词库
if ($bz == '生成词库'){
        if  ($qq == $zrqq){
            $ip=$_SERVER['HTTP_HOST'];
            $htip="$ht://$ip/banzhuan.php";
            echo '禁言菜单'."\n".'$访问 '."$htip".'?bz=禁言菜单$'."\n\n";
            echo '砸板砖'."\n".'$访问 '."$htip".'?bz=砸板砖菜单$'."\n\n";
            echo '新人获取'."\n".'$访问 '."$htip".'?bz=新人获取&qq=%QQ%$'."\n\n";
            echo '获取板砖'."\n".'$访问 '."$htip".'?bz=获取板砖$'."\n\n";
            echo '主人系统'."\n".'$访问 '."$htip".'?bz=主人系统$'."\n\n";
            echo '修改初始数量 .*'."\n".'$访问 '."$htip".'?bz=修改初始数量&qq=%QQ%&xgsl=%参数1%$'."\n\n";
            echo '修改每次砸板禁言时间 .*'."\n".'$访问 '."$htip".'?bz=修改每次砸板禁言时间&qq=%QQ%&x=%参数1%&d=%参数2%$'."\n\n";
            echo '砸板砖 .*'."\n".'A:$访问 '."$htip".'?bz=砸板砖&qq=%QQ%&atqq=%AT0%&qun=%群号%$'."\n".'$执行 %A%$'."\n\n";
            echo '查板砖数'."\n".'$访问 '."$htip".'?bz=查板砖数&qq=%QQ%$'."\n\n";
            echo '搬砖'."\n".'B:$访问 '."$htip".'?bz=搬砖&qq=%QQ%&qun=%群号%$'."\n".'$执行 %B%$'."\n\n";
            echo '偷砖'."\n".'C:$访问 '."$htip".'?bz=偷砖&qq=%QQ%&qun=%群号%$'."\n".'$执行 %C%$'."\n\n";
            echo '购买装备'."\n".'$访问 '."$htip".'?bz=购买装备$'."\n\n";
            echo '输出菜单'."\n".'$访问 '."$htip".'?bz=输出菜单&qq=%QQ%$'."\n\n";
            echo '生成词库 .*'."\n".'$访问 '."$htip".'?bz=生成词库&qq=%QQ%$&ht=%参数1%'."\n\n";
    }
    if  ($qq != $zrqq){
        echo  "您不是本API的主人";
    }
}